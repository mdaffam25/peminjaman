<?php

namespace App\Controllers;

use App\Models\PeminjamanModel;
use CodeIgniter\Controller;

class C_Peminjaman extends Controller
{
    protected $peminjamanModel;
    protected $db;

    public function __construct()
    {
        $this->peminjamanModel = new PeminjamanModel();
        $this->db = \Config\Database::connect(); // koneksi CI
    }
    
    // Method khusus untuk mengambil input 
    private function input() 
    {
        return $this->request->getPost($this->peminjamanModel->allowedFields);
    }

    // Tampilan Utama 
    public function index_peminjaman()
    {
        $data['peminjaman'] = $this->peminjamanModel->findAll();
        return view('peminjaman/index_peminjaman', $data);
    }

    // Cek apakah data ada di tabel 
    private function exists(string $table, string $field, $value)
    {
        return $this->db->table($table)->where($field, $value)->countAllResults() > 0;
    }

    // Tambah 
    public function tambah()
    {
        return view('peminjaman/tambah_peminjaman');
    }

    // Simpan
    public function simpan()
    {
        $data = $this->input();

    // Validasi data kosong
    foreach ($data as $key => $value) {
        if (empty($value)) {
            return redirect()->back()->with('error', 'Semua data harus diisi!');
        }
    }

        // Validasi foreign key
        if (!$this->exists('user', 'NIM', $data['NIM'])) {
        return redirect()->back()->with('error', 'NIM tidak ditemukan');
        }

        if (!$this->exists('fakultas', 'id_fakultas', $data['id_fakultas'])) {
        return redirect()->back()->with('error', 'ID Fakultas tidak ditemukan');
        }

        if (!$this->exists('fasilitas', 'id_fasilitas', $data['id_fasilitas'])) {
        return redirect()->back()->with('error', 'ID Fasilitas tidak ditemukan');
        }

        if (!$this->exists('ruangan', 'id_ruangan', $data['id_ruangan'])) {
        return redirect()->back()->with('error', 'ID Ruangan tidak ditemukan');
        }

        // Simpan data secara manual
        $sql = "INSERT INTO peminjaman (NIM, id_fakultas, id_fasilitas, id_ruangan, tanggal_peminjaman, waktu_mulai, waktu_selesai, keterangan)
                VALUES ('{$data['NIM']}', '{$data['id_fakultas']}', '{$data['id_fasilitas']}', 
                       '{$data['id_ruangan']}', '{$data['tanggal_peminjaman']}', '{$data['waktu_mulai']}', 
                       '{$data['waktu_selesai']}', '{$data['keterangan']}')";

        if ($this->db->query($sql)) {
            return redirect()->to('/peminjaman')->with('success', 'Data berhasil ditambah');
        }

        return redirect()->back()->with('error', 'Gagal menambah');
    }

    // Edit
    public function edit($id_peminjaman)
    {
        $data['peminjaman'] = $this->peminjamanModel->find($id_peminjaman);
        return view('peminjaman/edit_peminjaman', $data);
    }

    // Update
    public function update($id_peminjaman)
    {
        $data = $this->input();

    // Validasi data kosong
    foreach ($data as $key => $value) {
        if (empty($value)) {
            return redirect()->back()->with('error', 'Semua data harus diisi!');
        }
    }

        // Validasi foreign key
        if (!$this->exists('user', 'NIM', $data['NIM'])) {
        return redirect()->back()->with('error', 'NIM tidak ditemukan');
        }

        if (!$this->exists('fakultas', 'id_fakultas', $data['id_fakultas'])) {
        return redirect()->back()->with('error', 'ID Fakultas tidak ditemukan');
        }

        if (!$this->exists('fasilitas', 'id_fasilitas', $data['id_fasilitas'])) {
        return redirect()->back()->with('error', 'ID Fasilitas tidak ditemukan');
        }

        if (!$this->exists('ruangan', 'id_ruangan', $data['id_ruangan'])) {
        return redirect()->back()->with('error', 'ID Ruangan tidak ditemukan');
        }

        // Update data secara manual
        $sql = "UPDATE peminjaman SET
                NIM='{$data['NIM']}', id_fakultas='{$data['id_fakultas']}', id_fasilitas='{$data['id_fasilitas']}', 
                id_ruangan='{$data['id_ruangan']}', tanggal_peminjaman='{$data['tanggal_peminjaman']}', 
                waktu_mulai='{$data['waktu_mulai']}', waktu_selesai='{$data['waktu_selesai']}', keterangan='{$data['keterangan']}'
                WHERE id_peminjaman='$id_peminjaman'";

        if ($this->db->query($sql)) {
            return redirect()->to('/peminjaman')->with('success', 'Data berhasil diupdate');
        }

        return redirect()->back()->with('error', 'Gagal update');
    }

    // Delete
    public function delete($id_peminjaman)
    {
        // Delete data secara manual
        $sql = "DELETE FROM peminjaman WHERE id_peminjaman='$id_peminjaman'";
        if ($this->db->query($sql)) {
            return redirect()->to('/peminjaman')->with('success', 'Data berhasil dihapus');
        }

        return redirect()->back()->with('error', 'Gagal menghapus');
    }
}
