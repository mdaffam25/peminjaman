<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Tambah Fasilitas</h2>
    <form method="post" action="/fasilitas/simpan"> 

        <label>Nama Fasilitas</label>
        <input type="text" name="nama_fasilitas" id="nama_fasilitas">

        <button type="submit">Simpan</button>

        <a href="/fasilitas" class="btn-outline">Kembali</a>
    </form>
</div>