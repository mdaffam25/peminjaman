<?php

namespace App\Controllers;

use App\Models\PenggunaModel;
use CodeIgniter\Controller;

class C_Pengguna extends Controller
{
    protected $penggunaModel;
    protected $db;

    public function __construct()
    {
        $this->penggunaModel = new PenggunaModel();
        $this->db = \Config\Database::connect(); // koneksi CI
    }
    
    // Method khusus untuk mengambil input 
    private function input() 
    {
        return $this->request->getPost($this->penggunaModel->allowedFields);
    }

    // Tampilan Utama 
    public function index()
    {
        $data['pengguna'] = $this->penggunaModel->findAll();
        return view('pengguna/index', $data);
    }

    // Tambah 
    public function tambah()
    {
        return view('pengguna/tambah_pengguna');
    }

    // Simpan
    public function simpan()
    {
        $data = $this->input();

        // Validasi jika ada yang kosong
        if (empty($data['NIM']) || empty($data['nama']) || empty($data['no_telp'])) {
            return redirect()->back()->with('error', 'Semua data harus diisi!');
        }

        // Validasi jika NIM dan no_telp bukan angka
        if (!is_numeric($data['NIM']) || !is_numeric($data['no_telp'])) {
            return redirect()->back()->with('error', 'NIM dan Nomer Telepon harus berupa angka!');
        }

        // Validasi jika tidak ada datanya
        

        // Simpan data secara manual
        $sql = "INSERT INTO user (NIM, nama, no_telp)
                VALUES ('{$data['NIM']}', '{$data['nama']}', '{$data['no_telp']}')";

        if ($this->db->query($sql)) {
            return redirect()->to('/pengguna')->with('success', 'Data berhasil ditambah');
        }

        return redirect()->back()->with('error', 'Gagal menambah');
    }

    // Edit
    public function edit($nim)
    {
        $data['pengguna'] = $this->penggunaModel->find($nim);
        return view('pengguna/edit_pengguna', $data);
    }

    // Update
    public function update($nim)
    {
        $data = $this->input();

        // Validasi jika ada yang kosong
        if (empty($data['NIM']) || empty($data['nama']) || empty($data['no_telp'])) {
            return redirect()->back()->with('error', 'Semua data harus diisi!');
        }

        // Validasi jika NIM dan no_telp bukan angka
        if (!is_numeric($data['NIM']) || !is_numeric($data['no_telp'])) {
            return redirect()->back()->with('error', 'NIM dan Nomer Telepon harus berupa angka!');
        }

        // Update data secara manual
        $sql = "UPDATE user SET
                NIM='{$data['NIM']}',
                nama='{$data['nama']}',
                no_telp='{$data['no_telp']}'
                WHERE NIM='$nim'";

        if ($this->db->query($sql)) {
            return redirect()->to('/pengguna')->with('success', 'Data berhasil diupdate');
        }

        return redirect()->back()->with('error', 'Gagal update');
    }

    // Delete
    public function delete($nim)
    {
        // Delete data secara manual
        $sql = "DELETE FROM user WHERE NIM='$nim'";

        if ($this->db->query($sql)) {
            return redirect()->to('/pengguna')->with('success', 'Data berhasil dihapus');
        }

        return redirect()->back()->with('error', 'Gagal menghapus');
    }
}
