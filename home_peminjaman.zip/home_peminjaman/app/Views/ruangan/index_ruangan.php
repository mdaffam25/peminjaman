<link rel="stylesheet" href="/css/style.css">

<h2>Daftar Ruangan</h2>

<?php if(session()->getFlashdata('success')): ?>
<div class="alert success">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
<div class="alert error">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<a href="/ruangan/tambah" class="btn">Tambah Ruangan</a>

<a href="/" class="btn exit">Kembali ke Dashboard</a>

<br><br>

<table>
    <tr>
        <th>ID Ruangan</th>
        <th>Nama Ruangan</th>
        <th>Aksi</th>
    </tr>


    <?php foreach ($ruangan as $r): ?>
    <tr>
        <td><?= $r['id_ruangan'] ?></td>
        <td><?= $r['nama_ruangan'] ?></td>
        <td>
            <a href="/ruangan/edit/<?= $r['id_ruangan'] ?>" class="btn edit">Edit</a>
            <a href="/ruangan/delete/<?= $r['id_ruangan'] ?>" class="btn hapus" onclick="return confirm('Hapus data ini?')">Hapus</a>
        </td>
    </tr>
    

    <?php endforeach; ?>
</table>
