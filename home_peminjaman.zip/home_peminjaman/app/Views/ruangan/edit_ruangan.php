<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Edit Ruangan</h2>
<form method="post" action="/ruangan/update/<?=$ruangan['id_ruangan'] ?>">

   <label>ID Ruangan</label>
      <input type="text" name="id_ruangan" value="<?=$ruangan['id_ruangan'] ?>"readonly>

   <label>Nama Ruangan</label>
      <input type="text" name="nama_ruangan" value="<?=$ruangan['nama_ruangan'] ?>">

   <button type="submit">Update</button>

   <a href="/ruangan" class="btn-outline">Kembali</a>
</form>
</div>

