<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Edit Fasilitas</h2>
<form method="post" action="/fasilitas/update/<?=$fasilitas['id_fasilitas'] ?>">

   <label>ID Fasilitas</label>
      <input type="text" name="id_fasilitas" value="<?=$fasilitas['id_fasilitas'] ?>"readonly>

   <label>Nama Fasilitas</label>
      <input type="text" name="nama_fasilitas" value="<?=$fasilitas['nama_fasilitas'] ?>">

   <button type="submit">Update</button>

   <a href="/fasilitas" class="btn-outline">Kembali</a>
</form>
</div>

