<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Tambah Pengguna</h2>
    <form method="post" action="/pengguna/simpan"> 

        <label>NIM</label>
        <input type="text" name="NIM" id="NIM">

        <label>Nama</label>
        <input type="text" name="nama" id="nama">

        <label>Nomer Telepon</label>
        <input type="text" name="no_telp" id="no_telp">

        <button type="submit">Simpan</button>

        <a href="/pengguna" class="btn-outline">Kembali</a>
    </form>
</div>