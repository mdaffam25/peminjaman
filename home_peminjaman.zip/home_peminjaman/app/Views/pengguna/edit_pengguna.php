<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Edit Pengguna</h2>
<form method="post" action="/pengguna/update/<?=$pengguna['NIM'] ?>">

   <label>NIM</label>
      <input type="text" name="NIM" value="<?=$pengguna['NIM'] ?>">

   <label>Nama</label>
      <input type="text" name="nama" value="<?=$pengguna['nama'] ?>">

   <label>Nomer Telepon</label>
      <input type="text" name="no_telp" value="<?=$pengguna['no_telp'] ?>">

   <button type="submit">Update</button>

   <a href="/pengguna" class="btn-outline">Kembali</a>
</form>
</div>

