<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Tambah Fakultas</h2>
    <form method="post" action="/fakultas/simpan"> 

        <label>Nama Fakultas</label>
        <input type="text" name="nama_fakultas" id="nama_fakultas">

        <button type="submit">Simpan</button>

        <a href="/fakultas" class="btn-outline">Kembali</a>
    </form>
</div>