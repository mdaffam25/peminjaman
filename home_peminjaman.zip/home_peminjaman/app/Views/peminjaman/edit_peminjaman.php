<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Edit Peminjaman</h2>
<form method="post" action="/peminjaman/update/<?=$peminjaman['id_peminjaman'] ?>">

   <label>ID Peminjaman</label>
      <input type="text" name="id_peminjaman" value="<?=$peminjaman['id_peminjaman'] ?>"readonly>

   <label>NIM</label>
      <input type="text" name="NIM" value="<?=$peminjaman['NIM'] ?>">

   <label>ID Fakultas</label>
      <input type="text" name="id_fakultas" value="<?=$peminjaman['id_fakultas'] ?>">

   <label >ID Fasilitas</label>
      <input type="text" name="id_fasilitas" value="<?=$peminjaman['id_fasilitas'] ?>"> 

   <label>ID Ruangan</label>
      <input type="text" name="id_ruangan" value="<?=$peminjaman['id_ruangan'] ?>">   

    <label>Tanggal Peminjaman</label>
      <input type="date" name="tanggal_peminjaman" value="<?=$peminjaman['tanggal_peminjaman'] ?>">
      <br><br>

    <label>Waktu Mulai</label>
      <input type="time" name="waktu_mulai" value="<?=$peminjaman['waktu_mulai'] ?>">
      <br><br>
      
    <label>Waktu Selesai</label>
      <input type="time" name="waktu_selesai" value="<?=$peminjaman['waktu_selesai'] ?>">
      <br><br>

    <label>Keterangan</label>
      <input type="text" name="keterangan" value="<?=$peminjaman['keterangan'] ?>">  

   <button type="submit">Update</button>

   <a href="/peminjaman" class="btn-outline">Kembali</a>
</form>
</div>

