<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Tambah Peminjaman</h2>
    <form method="post" action="/peminjaman/simpan"> 

        <label>NIM</label>
        <input type="text" name="NIM" id="NIM">

        <label>ID Fakultas</label>
        <input type="text" name="id_fakultas" id="id_fakultas">

        <label>ID fasilitas</label>
        <input type="text" name="id_fasilitas" id="id_fasilitas">

        <label>ID Ruangan</label>
        <input type="text" name="id_ruangan" id="id_ruangan">

        <label>Tanggal Peminjaman</label>
        <input type="date" name="tanggal_peminjaman" id="tanggal_peminjaman">
        <br><br>

        <label>Waktu Mulai</label>
        <input type="time" name="waktu_mulai" id="waktu_mulai">
        <br><br>

        <label>Waktu Selesai</label>
        <input type="time" name="waktu_selesai" id="waktu_selesai">
        <br><br>

        <label>Keterangan</label>
        <input type="text" name="keterangan" id="keterangan">

        <button type="submit">Simpan</button>

        <a href="/peminjaman" class="btn-outline">Kembali</a>
    </form>
</div>