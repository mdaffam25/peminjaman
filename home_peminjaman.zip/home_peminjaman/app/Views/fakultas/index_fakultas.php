<link rel="stylesheet" href="/css/style.css">

<h2>Daftar Fakultas</h2>

<?php if(session()->getFlashdata('success')): ?>
<div class="alert success">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
<div class="alert error">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<a href="/fakultas/tambah" class="btn">Tambah Fakultas</a>

<a href="/" class="btn exit">Kembali ke Dashboard</a>

<br><br>

<table>
    <tr>
        <th>ID Fakultas</th>
        <th>Nama Fakultas</th>
        <th>Aksi</th>
    </tr>

    <?php foreach ($fakultas as $f): ?>
    <tr>
        <td><?= $f['id_fakultas'] ?></td>
        <td><?= $f['nama_fakultas'] ?></td>
        <td>
            <a href="/fakultas/edit/<?= $f['id_fakultas'] ?>" class="btn edit">Edit</a>
            <a href="/fakultas/delete/<?= $f['id_fakultas'] ?>" class="btn hapus" onclick="return confirm('Hapus data ini?')">Hapus</a>
        </td>
    </tr>
    

    <?php endforeach; ?>
</table>
