<link rel="stylesheet" href="/css/style.css">

<h2>Daftar Pengguna</h2>

<?php if(session()->getFlashdata('success')): ?>
<div class="alert success">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
<div class="alert error">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<a href="/pengguna/tambah" class="btn">Tambah Pengguna</a>

<a href="/" class="btn exit">Kembali ke Dashboard</a>

<br><br>

<table>
    <tr>
        <th>NIM</th>
        <th>Nama</th>
        <th>No Telepon</th>
        <th>Aksi</th>
    </tr>

    <?php foreach ($pengguna as $p): ?>
    <tr>
        <td><?= $p['NIM'] ?></td>
        <td><?= $p['nama'] ?></td>
        <td><?= $p['no_telp'] ?></td>
        <td>
            <a href="/pengguna/edit/<?= $p['NIM'] ?>" class="btn edit">Edit</a>
            <a href="/pengguna/delete/<?= $p['NIM'] ?>" class="btn hapus" onclick="return confirm('Hapus data ini?')">Hapus</a>
        </td>
    </tr>
    

    <?php endforeach; ?>
</table>
