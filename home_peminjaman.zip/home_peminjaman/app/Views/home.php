<html>
<head>
   <!--app/Views/home.php-->
    <title>Dashboard Peminjaman</title>
          <link rel="stylesheet" 
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

</head>

<body class="bg-light">

<div class="container py-5">
    <h2 class="text-center mb-4">Dashboard Sistem Peminjaman</h2>
    <br><br>

    <div class="row g-4">

        <!-- User CRUD -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>User</h5>
                   <!--  <p>Kelola data pengguna</p> -->
                    <a href="/pengguna" class="btn btn-primary w-100">Kelola User</a>
                </div>
            </div>
        </div>

        <!-- Fakultas CRUD -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>Fakultas</h5>
                    <!--  <p>Tambah, edit, hapus fakultas</p> -->
                    <a href="/fakultas" class="btn btn-primary w-100">Kelola Fakultas</a>
                </div>
            </div>
        </div>

        <!-- Fasilitas -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>Fasilitas</h5>
                    <a href="/fasilitas" class="btn btn-primary w-100">Kelola Fasilitas</a>
                </div>
            </div>
        </div>

        <!-- Ruangan -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>Ruangan</h5>
                    <a href="/ruangan" class="btn btn-primary w-100">Kelola Ruangan</a>
                </div>
            </div>
        </div>

        <!-- Peminjaman -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>Peminjaman</h5>
                    <a href="/peminjaman" class="btn btn-primary w-100">Kelola Peminjaman</a>
                </div>
            </div>
        </div>

        <!-- Riwayat Peminjaman -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>Riwayat Peminjaman</h5>
                    <a href="/peminjaman/riwayat" class="btn btn-primary w-100">Riwayat Peminjaman</a>
                </div>
            </div>
        </div>

        <!-- Cek Ketersediaan -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>Cek Ketersediaan Fasilitas & Ruangan</h5>
                    <a href="/cek-ketersediaan" class="btn btn-primary w-100">Cek Ketersediaan</a>
                </div>
            </div>
        </div>

        <!-- Log Peminjaman -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>Log & Arsip</h5>
                    <a href="/log" class="btn btn-primary w-100">Lihat Log & Arsip</a>
                </div>
            </div>
        </div>



    </div>
</div>

</body>
</html>
