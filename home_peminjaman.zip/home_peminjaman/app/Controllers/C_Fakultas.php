<?php

namespace App\Controllers;

use App\Models\FakultasModel;
use CodeIgniter\Controller;

class C_Fakultas extends Controller
{
    protected $fakultasModel;
    protected $db;

    public function __construct()
    {
        $this->fakultasModel = new FakultasModel();
        $this->db = \Config\Database::connect(); // koneksi CI
    }
    
    // Method khusus untuk mengambil input 
    private function input() 
    {
        return $this->request->getPost($this->fakultasModel->allowedFields);
    }

    // Tampilan Utama 
    public function index_fakultas()
    {
        $data['fakultas'] = $this->fakultasModel->findAll();
        return view('fakultas/index_fakultas', $data);
    }

    // Tambah 
    public function tambah()
    {
        return view('fakultas/tambah_fakultas');
    }

    // Simpan
    public function simpan()
    {
        $data = $this->input();

        // Validasi jika ada yang kosong
        if (empty($data['nama_fakultas'])) {
            return redirect()->back()->with('error', 'Nama Fakultas harus diisi!');
        }

        // Validasi jika nama fakultas bukan huruf
        if (!preg_match("/^[a-zA-Z ]+$/", $data['nama_fakultas'])) {
            return redirect()->back()->with('error', 'Nama Fakultas harus berupa huruf!');
        }

        // Simpan data secara manual
        $sql = "INSERT INTO fakultas (nama_fakultas)
                VALUES ('{$data['nama_fakultas']}')";

        if ($this->db->query($sql)) {
            return redirect()->to('/fakultas')->with('success', 'Data berhasil ditambah');
        }

        return redirect()->back()->with('error', 'Gagal menambah');
    }

    // Edit
    public function edit($id_fakultas)
    {
        $data['fakultas'] = $this->fakultasModel->find($id_fakultas);
        return view('fakultas/edit_fakultas', $data);
    }

    // Update
    public function update($id_fakultas)
    {
        $data = $this->input();

        // Validasi jika ada yang kosong
        if (empty($data['nama_fakultas'])) {
            return redirect()->back()->with('error', 'Nama Fakultas harus diisi!');
        }

        // Validasi jika nama fakultas bukan huruf
        if (!preg_match("/^[a-zA-Z ]+$/", $data['nama_fakultas'])) {
            return redirect()->back()->with('error', 'Nama Fakultas harus berupa huruf!');
        }

        // Update data secara manual
        $sql = "UPDATE fakultas SET
                nama_fakultas='{$data['nama_fakultas']}'
                WHERE id_fakultas='$id_fakultas'";

        if ($this->db->query($sql)) {
            return redirect()->to('/fakultas')->with('success', 'Data berhasil diupdate');
        }

        return redirect()->back()->with('error', 'Gagal update');
    }

    // Delete
    public function delete($id_fakultas)
    {
        // Delete data secara manual
        $sql = "DELETE FROM fakultas WHERE id_fakultas='$id_fakultas'";

        if ($this->db->query($sql)) {
            return redirect()->to('/fakultas')->with('success', 'Data berhasil dihapus');
        }

        return redirect()->back()->with('error', 'Gagal menghapus');
    }
}
