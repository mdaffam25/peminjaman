<?php

namespace App\Models;

use CodeIgniter\Model;

class PeminjamanModel extends Model
{
    protected $table = 'peminjaman';
    protected $primaryKey = 'id_peminjaman';
    protected $allowedFields = ['NIM', 'id_fakultas', 'id_fasilitas', 'id_ruangan', 'tanggal_peminjaman', 'waktu_mulai', 'waktu_selesai', 'keterangan'];
}