<link rel="stylesheet" href="/css/style.css">

    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert error">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>

<div class="form-container">
<h2>Edit Fakultas</h2>
<form method="post" action="/fakultas/update/<?=$fakultas['id_fakultas'] ?>">

   <label>ID Fakultas</label>
      <input type="text" name="id_fakultas" value="<?=$fakultas['id_fakultas'] ?>"readonly>

   <label>Nama Fakultas</label>
      <input type="text" name="nama_fakultas" value="<?=$fakultas['nama_fakultas'] ?>">

   <button type="submit">Update</button>

   <a href="/fakultas" class="btn-outline">Kembali</a>
</form>
</div>

