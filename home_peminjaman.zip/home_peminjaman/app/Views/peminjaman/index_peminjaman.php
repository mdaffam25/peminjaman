<link rel="stylesheet" href="/css/style.css">

<h2>Daftar Peminjaman</h2>

<?php if(session()->getFlashdata('success')): ?>
<div class="alert success">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
<div class="alert error">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<a href="/peminjaman/tambah" class="btn">Tambah Peminjaman</a>

<a href="/" class="btn exit">Kembali ke Dashboard</a>

<br><br>

<table>
    <tr>
        <th>ID Peminjaman</th>
        <th>NIM</th>
        <th>ID Fakultas</th>
        <th>ID Ruangan</th>
        <th>Tanggal Peminjaman</th>
        <th>Waktu Mulai</th>
        <th>Waktu Selesai</th>
        <th>Keterangan</th>
        <th>Aksi</th>
    </tr>

    <?php foreach ($peminjaman as $p): ?>
    <tr>
        <td><?= $p['id_peminjaman'] ?></td>
        <td><?= $p['NIM'] ?></td>
        <td><?= $p['id_fakultas'] ?></td>
        <td><?= $p['id_ruangan'] ?></td>
        <td><?= $p['tanggal_peminjaman'] ?></td>
        <td><?= $p['waktu_mulai'] ?></td>
        <td><?= $p['waktu_selesai'] ?></td>
        <td><?= $p['keterangan'] ?></td>
        <td>
            <a href="/peminjaman/edit/<?= $p['id_peminjaman'] ?>" class="btn edit">Edit</a>
            <a href="/peminjaman/delete/<?= $p['id_peminjaman'] ?>" class="btn hapus" onclick="return confirm('Hapus data ini?')">Hapus</a>
        </td>
    </tr>
    

    <?php endforeach; ?>
</table>
