<link rel="stylesheet" href="/css/style.css">

<h2>Daftar Fasilitas</h2>

<?php if(session()->getFlashdata('success')): ?>
<div class="alert success">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
<div class="alert error">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<a href="/fasilitas/tambah" class="btn">Tambah Fasilitas</a>

<a href="/" class="btn exit">Kembali ke Dashboard</a>

<br><br>

<table>
    <tr>
        <th>ID Fasilitas</th>
        <th>Nama Fasilitas</th>
        <th>Aksi</th>
    </tr>


    <?php foreach ($fasilitas as $f): ?>
    <tr>
        <td><?= $f['id_fasilitas'] ?></td>
        <td><?= $f['nama_fasilitas'] ?></td>
        <td>
            <a href="/fasilitas/edit/<?= $f['id_fasilitas'] ?>" class="btn edit">Edit</a>
            <a href="/fasilitas/delete/<?= $f['id_fasilitas'] ?>" class="btn hapus" onclick="return confirm('Hapus data ini?')">Hapus</a>
        </td>
    </tr>
    

    <?php endforeach; ?>
</table>
