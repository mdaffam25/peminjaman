<?php

namespace App\Controllers;

use App\Models\RuanganModel;
use CodeIgniter\Controller;

class C_Ruangan extends Controller
{
    protected $ruanganModel;
    protected $db;

    public function __construct()
    {
        $this->ruanganModel = new RuanganModel();
        $this->db = \Config\Database::connect(); // koneksi CI
    }
    
    // Method khusus untuk mengambil input 
    private function input() 
    {
        return $this->request->getPost($this->ruanganModel->allowedFields);
    }

    // Tampilan Utama 
    public function index_ruangan()
    {
        $data['ruangan'] = $this->ruanganModel->findAll();
        return view('ruangan/index_ruangan', $data);
    }

    // Tambah 
    public function tambah()
    {
        return view('ruangan/tambah_ruangan');
    }

    // Simpan
    public function simpan()
    {
        $data = $this->input();

        // Validasi jika ada yang kosong
        if (empty($data['nama_ruangan'])) {
            return redirect()->back()->with('error', 'Nama Ruangan harus diisi!');
        }

        // Simpan data secara manual
        $sql = "INSERT INTO ruangan (nama_ruangan)
                VALUES ('{$data['nama_ruangan']}')";

        if ($this->db->query($sql)) {
            return redirect()->to('/ruangan')->with('success', 'Data berhasil ditambah');
        }

        return redirect()->back()->with('error', 'Gagal menambah');
    }

    // Edit
    public function edit($id_ruangan)
    {
        $data['ruangan'] = $this->ruanganModel->find($id_ruangan);
        return view('ruangan/edit_ruangan', $data);
    }

    // Update
    public function update($id_ruangan)
    {
        $data = $this->input();

        // Validasi jika ada yang kosong
        if (empty($data['nama_ruangan'])) {
            return redirect()->back()->with('error', 'Nama Ruangan harus diisi!');
        }

        // Update data secara manual
        $sql = "UPDATE ruangan SET
                nama_ruangan='{$data['nama_ruangan']}'
                WHERE id_ruangan='$id_ruangan'";

        if ($this->db->query($sql)) {
            return redirect()->to('/ruangan')->with('success', 'Data berhasil diupdate');
        }

        return redirect()->back()->with('error', 'Gagal update');
    }

    // Delete
    public function delete($id_ruangan)
    {
        // Delete data secara manual
        $sql = "DELETE FROM ruangan WHERE id_ruangan='$id_ruangan'";
        if ($this->db->query($sql)) {
            return redirect()->to('/ruangan')->with('success', 'Data berhasil dihapus');
        }

        return redirect()->back()->with('error', 'Gagal menghapus');
    }
}
