<?php

namespace App\Controllers;

use App\Models\FasilitasModel;
use CodeIgniter\Controller;

class C_Fasilitas extends Controller
{
    protected $fasilitasModel;
    protected $db;

    public function __construct()
    {
        $this->fasilitasModel = new FasilitasModel();
        $this->db = \Config\Database::connect(); // koneksi CI
    }
    
    // Method khusus untuk mengambil input 
    private function input() 
    {
        return $this->request->getPost($this->fasilitasModel->allowedFields);
    }

    // Tampilan Utama 
    public function index_fasilitas()
    {
        $data['fasilitas'] = $this->fasilitasModel->findAll();
        return view('fasilitas/index_fasilitas', $data);
    }

    // Tambah 
    public function tambah()
    {
        return view('fasilitas/tambah_fasilitas');
    }

    // Simpan
    public function simpan()
    {
        $data = $this->input();

        // Validasi jika ada yang kosong
        if (empty($data['nama_fasilitas'])) {
            return redirect()->back()->with('error', 'Nama Fasilitas harus diisi!');
        }

        // Validasi jika nama fasilitas bukan huruf
        if (!preg_match("/^[a-zA-Z ]+$/", $data['nama_fasilitas'])) {
            return redirect()->back()->with('error', 'Nama Fasilitas harus berupa huruf!');
        }

        // Simpan data secara manual
        $sql = "INSERT INTO fasilitas (nama_fasilitas)
                VALUES ('{$data['nama_fasilitas']}')";

        if ($this->db->query($sql)) {
            return redirect()->to('/fasilitas')->with('success', 'Data berhasil ditambah');
        }

        return redirect()->back()->with('error', 'Gagal menambah');
    }

    // Edit
    public function edit($id_fasilitas)
    {
        $data['fasilitas'] = $this->fasilitasModel->find($id_fasilitas);
        return view('fasilitas/edit_fasilitas', $data);
    }

    // Update
    public function update($id_fasilitas)
    {
        $data = $this->input();

        // Validasi jika ada yang kosong
        if (empty($data['nama_fasilitas'])) {
            return redirect()->back()->with('error', 'Nama Fasilitas harus diisi!');
        }

        // Validasi jika nama fasilitas bukan huruf
        if (!preg_match("/^[a-zA-Z ]+$/", $data['nama_fasilitas'])) {
            return redirect()->back()->with('error', 'Nama Fasilitas harus berupa huruf!');
        }

        // Update data secara manual
        $sql = "UPDATE fasilitas SET
                nama_fasilitas='{$data['nama_fasilitas']}'
                WHERE id_fasilitas='$id_fasilitas'";

        if ($this->db->query($sql)) {
            return redirect()->to('/fasilitas')->with('success', 'Data berhasil diupdate');
        }

        return redirect()->back()->with('error', 'Gagal update');
    }

    // Delete
    public function delete($id_fasilitas)
    {
        // Delete data secara manual
        $sql = "DELETE FROM fasilitas WHERE id_fasilitas='$id_fasilitas'";
        if ($this->db->query($sql)) {
            return redirect()->to('/fasilitas')->with('success', 'Data berhasil dihapus');
        }

        return redirect()->back()->with('error', 'Gagal menghapus');
    }
}
