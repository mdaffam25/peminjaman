<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Router Setup
// $routes->setDefaultNamespace('App\Controllers');
// $routes->setDefaultController('Home');
// $routes->setDefaultMethod('index');
// $routes->setTranslateURIDashes(false);
// $routes->set404Override();
// $routes->setAutoRoute(true);
// App routes
// Home
$routes->get('/', 'Home::index');

// Pengguna
$routes->get('/pengguna', 'C_Pengguna::index');
$routes->get('/pengguna/tambah', 'C_Pengguna::tambah');
$routes->post('/pengguna/simpan', 'C_Pengguna::simpan');
$routes->get('/pengguna/edit/(:num)', 'C_Pengguna::edit/$1');
$routes->post('/pengguna/update/(:num)', 'C_Pengguna::update/$1');
$routes->get('/pengguna/delete/(:num)', 'C_Pengguna::delete/$1');

// Peminjaman
$routes->get('/peminjaman', 'C_Peminjaman::index_peminjaman');
$routes->get('/peminjaman/tambah', 'C_Peminjaman::tambah');
$routes->post('/peminjaman/simpan', 'C_Peminjaman::simpan');
$routes->get('/peminjaman/edit/(:num)', 'C_Peminjaman::edit/$1');
$routes->post('/peminjaman/update/(:num)', 'C_Peminjaman::update/$1');
$routes->get('/peminjaman/delete/(:num)', 'C_Peminjaman::delete/$1');

// Fasilitas
$routes->get('/fasilitas', 'C_Fasilitas::index_fasilitas');
$routes->get('/fasilitas/tambah', 'C_Fasilitas::tambah');
$routes->post('/fasilitas/simpan', 'C_Fasilitas::simpan');
$routes->get('/fasilitas/edit/(:num)', 'C_Fasilitas::edit/$1');
$routes->post('/fasilitas/update/(:num)', 'C_Fasilitas::update/$1');
$routes->get('/fasilitas/delete/(:num)', 'C_Fasilitas::delete/$1');

// Fakultas
$routes->get('/fakultas', 'C_Fakultas::index_fakultas');
$routes->get('/fakultas/tambah', 'C_Fakultas::tambah');
$routes->post('/fakultas/simpan', 'C_Fakultas::simpan');
$routes->get('/fakultas/edit/(:num)', 'C_Fakultas::edit/$1');
$routes->post('/fakultas/update/(:num)', 'C_Fakultas::update/$1');
$routes->get('/fakultas/delete/(:num)', 'C_Fakultas::delete/$1');

// Ruangan
$routes->get('/ruangan', 'C_Ruangan::index_ruangan');
$routes->get('/ruangan/tambah', 'C_Ruangan::tambah');
$routes->post('/ruangan/simpan', 'C_Ruangan::simpan');
$routes->get('/ruangan/edit/(:num)', 'C_Ruangan::edit/$1');
$routes->post('/ruangan/update/(:num)', 'C_Ruangan::update/$1');
$routes->get('/ruangan/delete/(:num)', 'C_Ruangan::delete/$1');